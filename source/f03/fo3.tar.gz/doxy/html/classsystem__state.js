var classsystem__state =
[
    [ "systemstate", "structsystem__state_1_1systemstate.html", "structsystem__state_1_1systemstate" ],
    [ "ssv", "classsystem__state.html#a8cd7e4a673778354e4a02b234d0f3c1f", null ],
    [ "ssv_temp", "classsystem__state.html#a2b1f803f0e6e8b225d824d0fa5adf52a", null ]
];