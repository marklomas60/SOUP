var searchData=
[
  ['gr0',['gr0',['../structpft__parameters_1_1pftparameters.html#aec00c95214a317c5d16c752027375ae8',1,'pft_parameters::pftparameters']]],
  ['grf',['grf',['../structpft__parameters_1_1pftparameters.html#ae8c00a9942924a59f4b5a2d6677a5d8c',1,'pft_parameters::pftparameters']]]
];
