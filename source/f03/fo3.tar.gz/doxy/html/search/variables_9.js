var searchData=
[
  ['jday',['jday',['../structsite__parameters_1_1siteparameters.html#a6eb7a4c998f427aedab40ec42bac6680',1,'site_parameters::siteparameters']]]
];
