var searchData=
[
  ['orgc',['orgc',['../structsite__parameters_1_1siteparameters.html#a61eff1a020f5b8331ae59481f2828ec6',1,'site_parameters::siteparameters']]]
];
