var searchData=
[
  ['data',['data',['../classdata.html',1,'']]],
  ['dims',['dims',['../classdims.html',1,'']]],
  ['doly',['doly',['../classdoly.html',1,'']]]
];
