var searchData=
[
  ['open_5ffiles',['open_files',['../classopen__files.html',1,'']]]
];
