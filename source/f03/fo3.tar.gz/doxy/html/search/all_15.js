var searchData=
[
  ['year',['year',['../structsite__parameters_1_1siteparameters.html#a3c32f4c812d9b57d8a4ed1f280bfa313',1,'site_parameters::siteparameters']]],
  ['year_5fout',['year_out',['../structmisc__parameters_1_1miscparameters.html#adefcd37a7f12909d2beb8174e6c0c734',1,'misc_parameters::miscparameters']]]
];
