var searchData=
[
  ['xamax',['xamax',['../classproductivity__methods.html#a610769e1ffdae198de4b6da137ab2d6d',1,'productivity_methods']]],
  ['xvjmax',['xvjmax',['../classproductivity__methods.html#a8ac3db82212bcfbf6952ce32524b137e',1,'productivity_methods']]]
];
