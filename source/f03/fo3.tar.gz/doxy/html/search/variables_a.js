var searchData=
[
  ['l_5fregional',['l_regional',['../structmisc__parameters_1_1miscparameters.html#a559a55b5512145af37f29fab7a30f79d',1,'misc_parameters::miscparameters']]],
  ['l_5fsnow',['l_snow',['../structsystem__state_1_1systemstate.html#a19a49914ca3624cc07aaadccf5f1d93f',1,'system_state::systemstate']]],
  ['lai',['lai',['../structsite__parameters_1_1siteparameters.html#abca14abb61d38ffa910e7107905a6037',1,'site_parameters::siteparameters::lai()'],['../structsystem__state_1_1systemstate.html#a0cb384facd4a6422e69ab85f9bca6f5e',1,'system_state::systemstate::lai()']]],
  ['lai_5fcomp_5flength',['lai_comp_length',['../classdims.html#af5316ed4c460d470146e2acd6038dd0d',1,'dims']]],
  ['lat',['lat',['../structsite__parameters_1_1siteparameters.html#a027d7759275813c08a7c1b77dfe0e925',1,'site_parameters::siteparameters']]],
  ['latres',['latres',['../structsite__parameters_1_1siteparameters.html#a7ae4a6667cc97c7e09165085d8b35027',1,'site_parameters::siteparameters']]],
  ['lls',['lls',['../structpft__parameters_1_1pftparameters.html#ae73fe1aa48be3d84f61d87ef02b7dc92',1,'pft_parameters::pftparameters']]],
  ['lmor',['lmor',['../structpft__parameters_1_1pftparameters.html#a2be0204dfb0f04c3442974980a21db2b',1,'pft_parameters::pftparameters']]],
  ['lon',['lon',['../structsite__parameters_1_1siteparameters.html#a7370656f2dd5ddac5d177f5cb16dc680',1,'site_parameters::siteparameters']]],
  ['lonres',['lonres',['../structsite__parameters_1_1siteparameters.html#a3f59cc0a7b1cc9570ecf873adaab8035',1,'site_parameters::siteparameters']]],
  ['lrat',['lrat',['../structpft__parameters_1_1pftparameters.html#a9e7e60080db2d37e1ccb0d65c7dc569d',1,'pft_parameters::pftparameters']]]
];
