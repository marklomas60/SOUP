var classdims =
[
    [ "lai_comp_length", "classdims.html#af5316ed4c460d470146e2acd6038dd0d", null ],
    [ "max_age", "classdims.html#aa15324a0525b271569105e0ae3fdd0a4", null ],
    [ "max_cohorts", "classdims.html#ab5e50f1c2fed320ec9d883423cf2fcbd", null ],
    [ "max_lai_comps", "classdims.html#ab7d80abcbe228d6c5cfa5c9c6880febc", null ],
    [ "max_pftps", "classdims.html#a8651814d86681de8fc8b215287c45fdd", null ],
    [ "max_root_comps", "classdims.html#a876266ee77e904aebd57bae85d29e284", null ],
    [ "max_stem_comps", "classdims.html#ae9af82f87a2587d7fcecb4fbef5a8f24", null ],
    [ "max_suma_comps", "classdims.html#a30bcd11de3c1333db5cbaf00680121c0", null ],
    [ "max_years", "classdims.html#a9ced9d2da3b580fa0a91e31d8b3d6e6f", null ],
    [ "root_comp_length", "classdims.html#a5382d5b22d2ca5e7fcf128d1fdf2ba63", null ],
    [ "stem_comp_length", "classdims.html#ad1358540d6794d498b7fb3d86fcd73e9", null ],
    [ "suma_comp_length", "classdims.html#aeb2a792cbf96a4daaa15a6d8df5a1787", null ]
];