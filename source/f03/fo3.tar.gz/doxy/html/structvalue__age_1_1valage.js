var structvalue__age_1_1valage =
[
    [ "age", "structvalue__age_1_1valage.html#a1fa90c28685da98e93a7519ce956061a", null ],
    [ "val", "structvalue__age_1_1valage.html#a449f501bb85c05a763b1fcc247764841", null ]
];