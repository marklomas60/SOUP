var classmisc__parameters =
[
    [ "miscparameters", "structmisc__parameters_1_1miscparameters.html", "structmisc__parameters_1_1miscparameters" ],
    [ "msp", "classmisc__parameters.html#a3d5c894601c28cce8a0cfae9bd8e8030", null ]
];