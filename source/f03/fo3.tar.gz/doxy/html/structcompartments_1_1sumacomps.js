var structcompartments_1_1sumacomps =
[
    [ "c", "structcompartments_1_1sumacomps.html#ae8b56afe5c3cdb6b7348e56769206d8c", null ],
    [ "no", "structcompartments_1_1sumacomps.html#af7e665855b8322eec5f856d0fc020eb7", null ],
    [ "tot", "structcompartments_1_1sumacomps.html#a6473be720b0db4c83e2941bdcb7af35c", null ]
];