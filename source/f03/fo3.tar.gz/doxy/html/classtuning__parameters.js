var classtuning__parameters =
[
    [ "tuningparameters", "structtuning__parameters_1_1tuningparameters.html", "structtuning__parameters_1_1tuningparameters" ],
    [ "tgp", "classtuning__parameters.html#a6d8fde001ad34822ce33cc5c533743d7", null ]
];