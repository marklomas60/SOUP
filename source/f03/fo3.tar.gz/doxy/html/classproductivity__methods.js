var classproductivity__methods =
[
    [ "assc4", "classproductivity__methods.html#a9e1755fcd54a82699be271e8c4351dac", null ],
    [ "assc42", "classproductivity__methods.html#ae3eaf7c37781c4deb63de1d0e02b926c", null ],
    [ "assj", "classproductivity__methods.html#a38ce1d36175eb6fb854550b510c52984", null ],
    [ "assj2", "classproductivity__methods.html#a37173194afdae9a41d5202dc510dcf95", null ],
    [ "assj3", "classproductivity__methods.html#a5f27ae455bda6dc9e56eb8dd24d8e199", null ],
    [ "assj4", "classproductivity__methods.html#a032fe06f6583b2ed26f7dd7c636aa506", null ],
    [ "assvmax", "classproductivity__methods.html#a422f6ec0e56a4d31338585413dbefd00", null ],
    [ "assvmax2", "classproductivity__methods.html#aa9baa2dca0ffa87cdb4bae6b77b2aa2d", null ],
    [ "assvmax3", "classproductivity__methods.html#a454e0d650a3fb8482d796435431714c0", null ],
    [ "limitationprocess", "classproductivity__methods.html#add090052aeb9464ac85d5640ba28b900", null ],
    [ "nppcalc", "classproductivity__methods.html#a217140109845d23092c5bb9cf1b529ce", null ],
    [ "xamax", "classproductivity__methods.html#a610769e1ffdae198de4b6da137ab2d6d", null ],
    [ "xvjmax", "classproductivity__methods.html#a8ac3db82212bcfbf6952ce32524b137e", null ]
];