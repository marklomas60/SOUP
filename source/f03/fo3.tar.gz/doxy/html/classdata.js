var classdata =
[
    [ "base72i", "classdata.html#acb3b416f83e176ebebf74fec81c7a544", null ],
    [ "bi_lin", "classdata.html#a7f237cdc24b1a6135d9cf3165167e634", null ],
    [ "ex_clim", "classdata.html#abf26fe19696d29326bc14d87a9240c02", null ],
    [ "ex_clim_site", "classdata.html#a4ab02b64f0e2688d7b39fb4e6dc347aa", null ],
    [ "ex_clu", "classdata.html#af2b4dd00be1f3285aa47e7b9fa2fd189", null ],
    [ "ex_lu", "classdata.html#a3da1e41057c0b17e59b1fa375553ce9b", null ],
    [ "ex_soil", "classdata.html#ada55c8a43952fd81596fe4f49fde0b7e", null ],
    [ "landuse1", "classdata.html#a59d63d92b2367fdc756f536c579afef0", null ],
    [ "lorc", "classdata.html#ad08f017a99ed74a1adf8a756de3a3568", null ],
    [ "n7", "classdata.html#ad43c36d15eed334522ae042c5de7cfac", null ],
    [ "readco2", "classdata.html#a8d2320dc9cdfde1a03f966d3440b5b71", null ]
];