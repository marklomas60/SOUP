var classsunshade =
[
    [ "beerslaw", "classsunshade.html#a2c67d65e545e72f209a863f2da991ec7", null ],
    [ "goudriaanslaw", "classsunshade.html#a5fb80e67d082ea3f667089add1c2c51a", null ],
    [ "goudriaanslaw2", "classsunshade.html#abcfbef92e0fc94a475289b315e8e3fc9", null ],
    [ "set_goud_params", "classsunshade.html#adde671cb42ba02152a2d1a91050feef6", null ],
    [ "sunflect", "classsunshade.html#af642be206636c98d14d5607c04acef78", null ]
];