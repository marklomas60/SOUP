var classdoly =
[
    [ "dolyday", "classdoly.html#a6454fc37a33192403a36d2b81253f12e", null ],
    [ "evapotranspiration", "classdoly.html#af574d471380a0d4a607fc85d66788af5", null ]
];