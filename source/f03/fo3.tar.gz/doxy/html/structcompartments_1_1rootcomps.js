var structcompartments_1_1rootcomps =
[
    [ "c", "structcompartments_1_1rootcomps.html#a4b3acd8087a4abc9b0c7877bfc0e0826", null ],
    [ "no", "structcompartments_1_1rootcomps.html#acf24c545bb24051480d0034ae0c010d9", null ],
    [ "tot", "structcompartments_1_1rootcomps.html#a5e719c14eb73d887e93cba5cb50d109d", null ]
];